package com.example.ProdManagement.Exception;

public class MyExceptions extends Exception{
}
